# Instant Reveal

Extensión para SillyTavern que muestra las respuestas completas **de una sola vez** al finalizar la generación, sin animación palabra por palabra.

## Instalación Manual

1. Copia esta carpeta dentro de `SillyTavern/extensions/`.
2. En SillyTavern, ve a **Settings → Extensions → Reload Extensions**.
3. Activa **"Instant Reveal"** y reinicia el chat o la aplicación.

## Instalación desde GitHub

1. Abre SillyTavern y ve a **Settings → Extensions → Install Extension**.
2. Pega la URL de este repositorio de GitHub.
3. Haz clic en "Install" y luego activa la extensión.
